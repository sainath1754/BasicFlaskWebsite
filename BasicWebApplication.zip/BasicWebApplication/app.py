from flask import Flask, request, render_template, redirect
from flask_wtf import CSRFProtect
from pymongo import MongoClient
import re

app = Flask(__name__)

app.config['SECRET_KEY'] = b'_53oi3uriq9pifpff;apl'
csrf = CSRFProtect(app)

@app.errorhandler(404)
def not_found(e):
    return render_template("404.html")

client = MongoClient('mongodb://localhost:27017/')
db = client['project']
collection = db['login_credentials']


@app.route("/")
def home():
    return render_template('navbar.html')

@app.route("/home")
def userloggedin():
    return render_template('main.html')

@app.route("/register", methods=['GET', 'POST'])
def register():
    if request.method == 'POST':
        name = request.form.get('Name')
        password = request.form.get('Password')
        email = request.form.get('email')
        mobile_number = request.form.get('number')
        if not name or not name.strip():
            return render_template('register.html')
        if not password or not password.strip():
            return render_template('register.html')
        if not re.match(r"^[a-zA-Z0-9_.+-]+@[a-zA-Z0-9-]+\.[a-zA-Z]+$", email):
            return render_template('register.html')
        if collection.find_one({'email': email}):
            return render_template('register.html')
        collection.insert_one({'name': name, 'password': password, 'email': email, 'mobile_number': mobile_number})
        return redirect('/login')
    return render_template('register.html')


@app.route("/login", methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        email = request.form.get('Email')
        password = request.form.get('Password')
        user = collection.find_one({'email': email, 'password': password})
        if user:
            return render_template('main.html')
    return render_template('login.html')



@app.route("/checkout")
def checkout():
    return render_template('checkout.html')


@app.route("/cart")
def cart():
    return render_template('cart.html')

@app.route("/store")
def store():
    return render_template('store.html')

@app.route("/index")
def index():
    return render_template('index.html')

@app.route("/about")
def about():
    return render_template('about.html')


@app.route("/logout")
def logout():
    return render_template('navbar.html')


@app.route("/notloginuser")
def notloginuser():
    return render_template('notloginuser.html')


if __name__ == '__main__':
    app.run(debug=True)
